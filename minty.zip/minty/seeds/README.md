# Minty Seed Library

## Installation

Copy the extension to phpBB/ext/minty/seeds

Go to "ACP" > "Customise" > "Extensions" and enable the "Minty Seed Library" extension.

## License

[GPLv2](license.txt)
# GR420SeedLibraryExtensionPHPBB
