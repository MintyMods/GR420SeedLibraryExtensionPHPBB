export declare function separator(item: any, widgetName: string): any;
