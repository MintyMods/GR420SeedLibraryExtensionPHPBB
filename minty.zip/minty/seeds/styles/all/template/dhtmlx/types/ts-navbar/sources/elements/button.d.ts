export declare function button(item: any, widgetName: string): any;
