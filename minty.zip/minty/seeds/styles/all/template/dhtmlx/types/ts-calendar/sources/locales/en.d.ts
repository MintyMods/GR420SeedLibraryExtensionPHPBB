declare const locale: {
    monthsShort: string[];
    months: string[];
    daysShort: string[];
    days: string[];
    cancel: string;
};
export default locale;
