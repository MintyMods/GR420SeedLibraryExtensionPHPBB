export declare function getFormatedDate(format: string, date: Date): string;
export declare function stringToDate(str: string, format: string, validate?: boolean): any;
