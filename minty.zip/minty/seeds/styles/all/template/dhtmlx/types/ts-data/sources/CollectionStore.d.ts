export declare const collectionStore: any;
