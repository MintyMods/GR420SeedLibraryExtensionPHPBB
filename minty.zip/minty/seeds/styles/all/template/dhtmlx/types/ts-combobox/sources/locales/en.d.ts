declare const _default: {
    notFound: string;
    selectAll: string;
    unselectAll: string;
    selectedItems: string;
};
export default _default;
