declare const _default: {
    simpleVaultText: string;
    simpleVaultLabel: string;
};
export default _default;
