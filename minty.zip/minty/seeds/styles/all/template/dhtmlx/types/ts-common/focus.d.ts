export declare const getFocus: () => any;
