export declare function imageButton(item: any, widgetName: string): any;
