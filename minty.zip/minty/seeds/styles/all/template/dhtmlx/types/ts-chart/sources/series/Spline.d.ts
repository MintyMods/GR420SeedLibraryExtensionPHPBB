import { PointData } from "../types";
import Line from "./Line";
export default class Spline extends Line {
    protected _getForm(points: PointData[], config: any, css: string, width: number, height: number): object;
}
