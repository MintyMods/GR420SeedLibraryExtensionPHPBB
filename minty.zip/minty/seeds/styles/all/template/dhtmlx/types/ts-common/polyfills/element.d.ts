declare const reduce: any;
declare const isEnumerable: any;
declare const concat: any;
