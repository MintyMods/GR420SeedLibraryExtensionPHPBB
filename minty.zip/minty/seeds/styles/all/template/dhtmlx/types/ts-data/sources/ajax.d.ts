import { IAjaxHelper } from "./types";
export declare const ajax: IAjaxHelper;
